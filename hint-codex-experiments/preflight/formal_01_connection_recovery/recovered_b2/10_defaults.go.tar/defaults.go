package parser

import "github.com/mattn/anko/ast"

// scanDefaults removes default expressions from the token stream seen by the
// generated parser, while parsing the expressions with the same parser.
func (l *Lexer) scanDefaults(pos ast.Position) {
	s := *l.s
	tok, _, _, err := s.Scan()
	if tok == IDENT {
		tok, _, _, err = s.Scan()
	}
	if err != nil || tok != '(' {
		return
	}
	var defaults []ast.Expr
	type span struct{ start, end int }
	var spans []span
	seenDefault := false
	for {
		tok, _, _, err = s.Scan()
		if err != nil || tok == EOF {
			return
		}
		if tok == ')' {
			break
		}
		if tok != IDENT {
			return
		}
		tok, _, p, err := s.Scan()
		if err != nil {
			return
		}
		var def ast.Expr
		if tok == '=' {
			start := s.offset
			depth := 0
			end := start
			for {
				s.skipBlank()
				end = s.offset
				tok, _, p, err = s.Scan()
				if err != nil || tok == EOF {
					return
				}
				if depth == 0 && (tok == ',' || tok == ')' || tok == VARARG) {
					break
				}
				switch tok {
				case '(', '[', '{':
					depth++
				case ')', ']', '}':
					depth--
				}
				if depth < 0 {
					return
				}
			}
			if tok == VARARG {
				l.defaultErr = &Error{Message: "invalid default argument declaration", Pos: p}
				return
			}
			stmt, parseErr := ParseSrc("return " + string(s.src[start:end]))
			if parseErr != nil {
				l.defaultErr = parseErr
				return
			}
			stmts, ok := stmt.(*ast.StmtsStmt)
			if !ok || len(stmts.Stmts) != 1 {
				l.defaultErr = &Error{Message: "syntax error", Pos: p}
				return
			}
			ret, ok := stmts.Stmts[0].(*ast.ReturnStmt)
			if !ok || len(ret.Exprs) != 1 {
				l.defaultErr = &Error{Message: "syntax error", Pos: p}
				return
			}
			def = ret.Exprs[0]
			seenDefault = true
			// Include the '=' in the removed range.
			spans = append(spans, span{start - 1, end})
		} else if tok != VARARG && seenDefault {
			l.defaultErr = &Error{Message: "invalid default argument declaration", Pos: p}
			return
		}
		defaults = append(defaults, def)
		if tok == VARARG {
			tok, _, p, err = s.Scan()
			if tok == '=' {
				l.defaultErr = &Error{Message: "invalid default argument declaration", Pos: p}
				return
			}
			if err != nil || tok != ')' {
				return
			}
			break
		}
		if tok == ')' {
			break
		}
		if tok != ',' {
			return
		}
		// The grammar permits newlines after commas.
		for s.peek() == '\n' || isBlank(s.peek()) {
			s.next()
		}
	}
	if !seenDefault {
		return
	}
	for _, sp := range spans {
		for i := sp.start; i < sp.end; i++ {
			if l.s.src[i] == '\n' {
				l.defaultNewlines[i] = true
			} else {
				l.s.src[i] = ' '
			}
		}
	}
	l.defaults[pos] = defaults
}
