"""Check experiment scheduling and isolation without running models or Docker."""

import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "source"))
from benchmark.deepswe import run_loop_by_hint as hint_loop  # noqa: E402
import run_codex_experiments as paired  # noqa: E402
import report_codex_experiments as reporting  # noqa: E402


def outcome(solved=False):
    return {"solved": solved, "exit_code": 0 if solved else 1,
            "eval": {"reward": 1 if solved else 0, "solved": solved}}


class BaselineRoundsTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.directory.cleanup()

    def loop(self, extra=()):
        args = hint_loop.build_parser().parse_args([
            "--instance_id", "offline-task", "--run_name", "offline-baseline",
            "--output_base", self.directory.name, "--api_key", "codex-local",
            "--no_hint_run", "--dry_run", *extra,
        ])
        return hint_loop.HintLoopOrchestrator(args)

    def test_original_default_is_one_attempt_even_with_max_rounds_five(self):
        loop = self.loop()
        with patch.object(loop, "step_solve", return_value=outcome()) as solve:
            self.assertEqual(loop.run(), 1)
        solve.assert_called_once_with(1, no_hint=True)
        self.assertEqual(loop.summary["max_rounds"], 1)
        self.assertEqual(loop.summary["rounds"][0]["status"], "not_solved")

    def test_requested_five_attempts_do_not_silently_reuse_old_results(self):
        loop = self.loop(["--baseline_rounds", "5"])
        with patch.object(loop, "step_solve", return_value=outcome()) as solve, \
                patch.object(loop, "_find_eval_result", return_value={"solved": True}) as previous:
            self.assertEqual(loop.run(), 1)
        self.assertEqual([call.args[0] for call in solve.call_args_list], [1, 2, 3, 4, 5])
        self.assertTrue(all(call.kwargs == {"no_hint": True} for call in solve.call_args_list))
        previous.assert_not_called()
        self.assertEqual(loop.summary["total_rounds"], 5)

    def test_early_pass_stops_remaining_attempts(self):
        loop = self.loop(["--baseline_rounds", "5"])
        with patch.object(loop, "step_solve", side_effect=[outcome(), outcome(True)]) as solve:
            self.assertEqual(loop.run(), 0)
        self.assertEqual(solve.call_count, 2)
        self.assertTrue(loop.summary["solved"])
        self.assertEqual(loop.summary["solved_round"], 2)

    def test_incomplete_attempt_is_distinct_from_a_normal_failed_evaluation(self):
        loop = self.loop(["--baseline_rounds", "5"])
        with patch.object(loop, "step_solve", side_effect=[outcome(), None]) as solve:
            self.assertEqual(loop.run(), 2)
        self.assertEqual(solve.call_count, 2)
        self.assertEqual([row["status"] for row in loop.summary["rounds"]],
                         ["not_solved", "incomplete"])
        self.assertFalse(loop.summary["solved"])
        self.assertNotIn("eval", loop.summary["rounds"][1])


class PairedDriverTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.args = SimpleNamespace(
            output_base=self.directory.name, experiment_name="offline",
            stage="formal", api_base="http://model-bridge:8765",
            container_api_base="http://guest-model-bridge:8765",
            progress_base="http://progress:8766",
            container_progress_base="http://guest-progress:8766", dry_run=True,
        )
        self.driver = paired.PairedExperiments(self.args)

    def tearDown(self):
        self.directory.cleanup()

    def test_group_configuration_is_matched_and_only_i_enables_online_guidance(self):
        loops = {group: self.driver.loop("offline-task", group, "shared-state.json")
                 for group in paired.GROUPS}
        for group, loop in loops.items():
            self.assertEqual(loop.args.model_name, "gpt-6.1-terra")
            self.assertEqual(loop.args.container_cpus, 8)
            self.assertEqual(loop.args.mem_limit, "128g")
            self.assertEqual(loop.args.max_rounds, 5)
            self.assertEqual(loop.args.baseline_rounds, 5)
            self.assertFalse(loop.args.continue_run)
            self.assertEqual(loop.args.no_hint_run, group == "B")
            self.assertEqual(bool(loop.args.teacher_progress_url), group == "I")
            self.assertEqual(loop.args.teacher_session_mode, "resume" if group == "M" else "fresh")
        self.assertEqual(len({loop.args.codex_session for loop in loops.values()}), 4)

    def test_each_student_round_has_new_session_and_one_original_solver_attempt(self):
        loop = self.driver.loop("offline-task", "B")
        with patch.object(hint_loop, "run_step", return_value=0) as run:
            loop.step_solve(1, no_hint=True)
            loop.step_solve(2, no_hint=True)
        commands = [call.args[1] for call in run.call_args_list]
        sessions = [command[command.index("--experiment_session") + 1] for command in commands]
        self.assertEqual(sessions, ["offline-offline-task-B-r1", "offline-offline-task-B-r2"])
        names = [command[command.index("--run_name") + 1] for command in commands]
        self.assertEqual(names, ["offline_B_r1", "offline_B_r2"])
        for command in commands:
            self.assertEqual(command[command.index("--max_turns") + 1], "1")
            self.assertNotIn("--hint_path", command)
            self.assertNotIn("--resume_session_id", command)

    def test_m_teacher_url_keeps_identity_while_h_starts_fresh_reviews(self):
        shared_session = "offline-offline-task-shared"
        loops = {group: self.driver.loop("offline-task", group, "shared-state.json")
                 for group in ("H", "M")}
        with patch.object(hint_loop, "run_step", return_value=0) as run:
            loops["M"].step_review(1)
            loops["M"].step_review(2)
            loops["H"].step_review(1)
            loops["H"].step_review(2)
        commands = [call.args[1] for call in run.call_args_list]
        urls = [command[command.index("--api_base") + 1] for command in commands]
        self.assertIn(f"/sessions/{shared_session}/teacher/review_r1/v1", urls[0])
        self.assertIn(f"/sessions/{shared_session}/teacher/review_r2/v1", urls[1])
        self.assertIn("/sessions/offline-offline-task-H-review-r1/teacher/review_r1/v1", urls[2])
        self.assertIn("/sessions/offline-offline-task-H-review-r2/teacher/review_r2/v1", urls[3])
        self.assertTrue(all(url.startswith("http://guest-model-bridge:8765/") for url in urls))

    def test_all_hint_groups_receive_identical_initial_full_and_compressed_hints(self):
        self.driver.args.dry_run = False
        shared = self.driver.loop("offline-task", "shared")
        shared.hint_gen_dir.mkdir(parents=True, exist_ok=True)
        originals = {
            shared.full_hint_path: "A shared full teacher guide.\n",
            shared.golden_diff_path: "A fixed reference patch.\n",
            shared._hint_path_for_round(1): "A shared compressed student guide.\n",
        }
        for path, text in originals.items():
            path.write_text(text)
        for group in ("H", "M", "I"):
            loop = self.driver.loop("offline-task", group, "shared-state.json")
            self.driver.use_shared(loop, shared)
            self.assertEqual(loop.full_hint_path.read_text(), originals[shared.full_hint_path])
            self.assertEqual(loop.golden_diff_path.read_text(), originals[shared.golden_diff_path])
            self.assertEqual(loop._hint_path_for_round(1).read_text(), originals[shared._hint_path_for_round(1)])

    def test_five_round_schedule_is_paired_rotates_order_and_stops_solved_groups(self):
        attempts = []
        shared = SimpleNamespace(args=SimpleNamespace(teacher_state="shared-state.json"))
        pass_at = {"B": 2, "H": 1, "M": None, "I": 3}

        def attempt(task, group, loop, round_num, reviews):
            self.assertFalse(loop.args.continue_run)
            attempts.append((task, group, round_num))
            return pass_at[group] == round_num

        with patch.object(paired, "TASKS", ("task-a", "task-b")), \
                patch.object(self.driver, "prepare_shared", return_value=shared) as prepare, \
                patch.object(self.driver, "use_shared") as use_shared, \
                patch.object(self.driver, "run_attempt", side_effect=attempt), \
                patch.object(paired, "write_reports"), \
                patch.object(self.driver, "close_teachers"):
            self.assertEqual(self.driver.run(), 0)
        self.assertEqual(prepare.call_count, 2)
        self.assertEqual(use_shared.call_count, 6)
        for task in ("task-a", "task-b"):
            for group in paired.GROUPS:
                rounds = [number for item, condition, number in attempts if item == task and condition == group]
                expected = pass_at[group] or 5
                self.assertEqual(rounds, list(range(1, expected + 1)))
        first = [group for task, group, number in attempts if task == "task-a" and number == 1]
        second = [group for task, group, number in attempts if task == "task-b" and number == 1]
        self.assertEqual(first, ["B", "H", "M", "I"])
        self.assertEqual(second, ["H", "M", "I", "B"])
        self.assertEqual(self.driver.state["status"], "complete")

    def test_compression_failure_still_tracks_initial_teacher_for_cleanup(self):
        shared = SimpleNamespace(
            args=SimpleNamespace(), hint_gen_dir=Path(self.directory.name) / "shared",
            step_get_hint=Mock(return_value=True),
            step_compress=Mock(side_effect=RuntimeError("Teacher quota reached")),
        )
        with patch.object(self.driver, "loop", return_value=shared):
            with self.assertRaisesRegex(RuntimeError, "quota"):
                self.driver.prepare_shared("offline-task")
        self.assertEqual(self.driver.kept_teachers,
                         [Path(self.directory.name) / "shared" / "teacher_state.json"])

    def test_incomplete_attempt_stops_driver_and_upstream_without_retry(self):
        self.driver.args.dry_run = False
        with patch.object(paired, "TASKS", ("task-a",)), \
                patch.object(self.driver, "bridge_status", return_value={"stopped": False}), \
                patch.object(hint_loop.HintLoopOrchestrator, "step_solve", return_value=None) as solve, \
                patch.object(paired, "request_json", return_value={"stopped": True}) as stop, \
                patch.object(paired, "write_reports"), \
                patch.object(self.driver, "close_teachers"):
            self.assertEqual(self.driver.run(), 2)
        solve.assert_called_once_with(1, no_hint=True)
        self.assertEqual(self.driver.state["status"], "stopped")
        self.assertEqual(len(self.driver.state["attempts"]), 1)
        self.assertEqual(self.driver.state["attempts"][0]["status"], "incomplete")
        self.assertEqual(stop.call_args.args[0], "http://model-bridge:8765/stop")
        self.assertIn("formal evaluation", stop.call_args.args[1]["reason"])
        self.assertEqual(self.driver.state["quota_policy"], "save_and_stop_without_automatic_resume")

    def resume_fixture(self, after_thread):
        self.driver.args.dry_run = False
        loop = self.driver.loop("offline-task", "H", "shared-state.json")
        shared = self.driver.loop("offline-task", "shared")
        session = "offline-offline-task-shared"
        shared.args.teacher_codex_session = session
        shared.args.teacher_state = "shared-state.json"
        before = {"stopped": False, "sessions": [
            {"session": session, "role": "teacher", "phase": "generate", "thread_id": "teacher-original"},
            {"session": "unrelated", "role": "teacher", "phase": "generate", "thread_id": "other"},
        ]}
        after = {"stopped": False, "sessions": [
            {"session": session, "role": "teacher", "phase": "resume_probe", "thread_id": after_thread},
        ]}

        def review(step, command, log_path, env=None):
            output = self.driver.output / "teacher_resume_probe" / "review.json"
            output.write_text(json.dumps({"used_hint": True}))
            return 0

        return loop, shared, (before, {"stopped": False}, after), review

    def test_teacher_resume_probe_passes_only_with_same_shared_thread(self):
        loop, shared, snapshots, review = self.resume_fixture("teacher-original")
        loop.summary["solved"] = True
        with patch.object(self.driver, "bridge_status", side_effect=snapshots), \
                patch.object(paired, "run_step", side_effect=review) as run:
            self.driver.verify_teacher_resume(loop, shared)
        probe = self.driver.state["teacher_resume_probe"]
        self.assertTrue(probe["passed"])
        self.assertEqual(probe["before_threads"], ["teacher-original"])
        command = run.call_args.args[1]
        self.assertEqual(command[command.index("--teacher_session") + 1], "resume")
        self.assertIn("--solved", command)
        self.assertIn("/sessions/offline-offline-task-shared/teacher/resume_probe/v1",
                      command[command.index("--api_base") + 1])

    def test_teacher_resume_probe_rejects_successful_review_on_new_thread(self):
        loop, shared, snapshots, review = self.resume_fixture("teacher-replacement")
        with patch.object(self.driver, "bridge_status", side_effect=snapshots), \
                patch.object(paired, "run_step", side_effect=review):
            with self.assertRaisesRegex(RuntimeError, "persistent teacher"):
                self.driver.verify_teacher_resume(loop, shared)
        probe = self.driver.state["teacher_resume_probe"]
        self.assertFalse(probe["passed"])
        self.assertTrue((self.driver.output / "teacher_resume_probe" / "review.json").is_file())
        saved = json.loads(self.driver.summary_path.read_text())
        self.assertFalse(saved["teacher_resume_probe"]["passed"])

    def test_existing_name_is_rejected_and_new_name_preserves_previous_results(self):
        self.driver.state["status"] = "stopped"
        self.driver.state["stop_reason"] = "Preserve this earlier result"
        self.driver.save()
        original = self.driver.summary_path.read_bytes()
        artifact = self.driver.output / "previous-patch.diff"
        artifact.write_text("Existing patch contents\n")
        with self.assertRaisesRegex(FileExistsError, "new experiment name"):
            paired.PairedExperiments(self.args)
        self.assertEqual(self.driver.summary_path.read_bytes(), original)
        self.assertEqual(artifact.read_text(), "Existing patch contents\n")
        new_args = SimpleNamespace(**{**vars(self.args), "experiment_name": "another-offline-run"})
        new_driver = paired.PairedExperiments(new_args)
        new_driver.save()
        self.assertNotEqual(new_driver.output, self.driver.output)
        self.assertEqual(self.driver.summary_path.read_bytes(), original)

    def test_final_integration_report_keeps_stopped_status_and_original_reason(self):
        self.args.stage = "integration"
        self.args.dry_run = False
        self.driver = paired.PairedExperiments(self.args)
        bridge = Path(self.directory.name) / "logs" / "bridge"
        progress = Path(self.directory.name) / "logs" / "progress"
        bridge.mkdir(parents=True)
        progress.mkdir(parents=True)

        def write_local_reports(state_path, ignored_bridge, ignored_progress):
            return reporting.write_reports(state_path, bridge, progress)

        reason = "SDK fixture did not exercise a permitted edit"
        with patch.object(self.driver, "prepare_shared", side_effect=RuntimeError(reason)), \
                patch.object(paired, "request_json", return_value={"stopped": True}), \
                patch.object(paired, "write_reports", side_effect=write_local_reports), \
                patch.object(self.driver, "close_teachers"):
            self.assertEqual(self.driver.run(), 2)
        metrics = json.loads((self.driver.output / "metrics.json").read_text())
        report = (self.driver.output / "report.md").read_text()
        self.assertEqual(metrics["stage"], "integration")
        self.assertEqual(metrics["status"], "stopped")
        self.assertEqual(metrics["stop_reason"], reason)
        self.assertIn("# Codex Hint 联调报告", report)
        self.assertIn("状态：stopped", report)
        self.assertIn("停止原因：" + reason, report)
        self.assertEqual(metrics["attempts"], [])


if __name__ == "__main__":
    unittest.main()
