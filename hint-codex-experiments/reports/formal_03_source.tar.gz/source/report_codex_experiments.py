#!/usr/bin/env python3
"""Aggregate measured Codex usage and paired experiment outcomes."""

import argparse
import csv
import json
import re
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

TOKEN_FIELDS = {
    "input_tokens": "inputTokens", "cached_input_tokens": "cachedInputTokens",
    "output_tokens": "outputTokens", "reasoning_output_tokens": "reasoningOutputTokens",
    "total_tokens": "totalTokens",
}
COUNTERS = tuple(TOKEN_FIELDS) + (
    "token_events", "request_count", "response_count", "error_count", "request_seconds",
    "codex_turn_count", "codex_turn_seconds",
)
DIMENSIONS = ("scope", "experiment", "task", "group", "round", "role", "stage", "phase")
STAGES = {
    "initial_teacher": "初始教师生成", "initial_compression": "首轮指导压缩",
    "compression": "后续指导压缩", "success_review": "成功轨迹审查",
    "failure_review": "失败复盘", "online_teacher": "轮内教师判断",
    "online_hint_screen": "轮内提示筛查", "student": "学生解题",
}


def read_json(path, default=None):
    path = Path(path)
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else default


def records(path):
    path = Path(path)
    if path.is_file():
        with path.open(encoding="utf-8") as stream:
            for line in stream:
                if line.strip():
                    # The final line may still be in flight while a progress report is written.
                    if not line.endswith("\n"):
                        break
                    yield json.loads(line)


def counters():
    return {name: 0 for name in COUNTERS}


def add_counters(target, source):
    for name in COUNTERS:
        target[name] += source.get(name, 0) or 0


def experiment_catalog(state_path, current):
    catalog = {}
    for path in Path(state_path).parent.parent.glob("*/experiment_state.json"):
        item = read_json(path)
        if item and item.get("experiment"):
            catalog[item["experiment"]] = item
    catalog[current["experiment"]] = current
    return catalog


def attribution(record, catalog):
    session = record.get("session") or ""
    phase = record.get("phase") or "unknown"
    role = record.get("role") or "unknown"
    result = dict.fromkeys(DIMENSIONS)
    result.update(scope="preflight" if session.startswith("preflight") else "other_sessions",
                  role=role, phase=phase, stage=phase)
    for name in sorted(catalog, key=len, reverse=True):
        if not session.startswith(name + "-"):
            continue
        state = catalog[name]
        result.update(scope="dry_run" if state.get("dry_run") else state.get("stage", "unknown"),
                      experiment=name)
        tasks = set(state.get("tasks", [])) | set(state.get("selected_tasks", []))
        tasks.update(row["task"] for row in state.get("attempts", []))
        for task in sorted(tasks, key=len, reverse=True):
            prefix = name + "-" + task + "-"
            if not session.startswith(prefix):
                continue
            suffix = session[len(prefix):]
            result["task"] = task
            result["group"] = suffix.split("-", 1)[0].split("_", 1)[0]
            match = re.search(r"(?:^|_)r(\d+)(?:$|_)", phase)
            if not match:
                match = re.search(r"-(?:review-)?r(\d+)(?:$|_|-)", "-" + suffix)
            result["round"] = int(match.group(1)) if match else None
            if result["group"] == "shared" and phase.startswith("review_r"):
                result["group"] = "M"
            elif phase == "resume_probe":
                result["group"] = "teacher_resume_probe"
                result["stage"] = "teacher_resume_probe"
            break
        if phase == "generate":
            result["stage"] = "initial_teacher"
        elif phase.startswith("compress_r"):
            result["stage"] = "initial_compression" if result["group"] == "shared" else "compression"
        elif phase.startswith("review_r"):
            solved = any(row["task"] == result["task"] and row["group"] == result["group"]
                         and row["round"] == result["round"] and row["status"] == "solved"
                         for row in state.get("attempts", []))
            result["stage"] = "success_review" if solved else "failure_review"
        elif "progress_" in phase:
            result["stage"] = "online_hint_screen" if "screen" in phase else "online_teacher"
        elif role == "student":
            result["stage"] = "student"
        return result
    return result


def attempt_metrics(entry, experiment, progress):
    result = {key: entry.get(key) for key in ("task", "group", "round", "status", "eval_path", "trajs_path")}
    result["attempt_wall_seconds"] = entry.get("elapsed_seconds")
    metadata = read_json(entry.get("trajs_path") or "/nonexistent", {}).get("metadata", {})
    execution = entry.get("execution") or {}
    if not execution and entry.get("trajs_path"):
        path = Path(entry["trajs_path"])
        for parent in (path.parent, path.parent.parent):
            rounds = read_json(parent / "rounds_meta.json", {}).get("rounds", [])
            if rounds:
                execution = rounds[-1].get("execution") or {}
                break
    session = f"{experiment}-{entry['task']}-{entry['group']}-r{entry['round']}"
    checks = [record for record in progress if record.get("session") == session]
    wall = metadata.get("wall_seconds", execution.get("wall_seconds"))
    wait = metadata.get("teacher_wait_seconds", execution.get("teacher_wait_seconds"))
    wait_source = "student_metadata" if "teacher_wait_seconds" in metadata else "runner_execution"
    if wait is None and checks:
        wait = sum(record.get("duration_seconds", 0) for record in checks)
        wait_source = "teacher_service"
    if wait is None and entry["group"] != "I":
        wait, wait_source = 0.0, "no_online_teacher"
    if wait is None:
        wait_source = None
    result.update(student_wall_seconds=wall, teacher_wait_seconds=wait,
                  teacher_wait_source=wait_source,
                  student_active_seconds=(wall - wait if wall is not None and wait is not None else None),
                  teacher_checks=metadata.get("teacher_checks", len(checks)),
                  delivered_hints=sum(bool(record.get("hint")) for record in checks),
                  stop_reason=execution.get("stop_reason") or metadata.get("error_log"))
    evaluation = entry.get("eval") or {}
    raw_evaluation = read_json(entry.get("eval_path") or "/nonexistent", {})
    for key in ("reward", "f2p_passed", "f2p_total", "p2p_passed", "p2p_total"):
        value = evaluation.get(key)
        result[key] = value if value is not None else raw_evaluation.get(key)
    return result


def outcomes(state, attempts):
    groups = state.get("groups", ["B", "H", "M", "I"])
    tasks = state.get("selected_tasks")
    if tasks is None:
        tasks = (state.get("tasks", []) if state.get("stage") == "formal"
                 else sorted({row["task"] for row in attempts}))
    base_tasks = list(tasks)
    limit = state.get("round_limit", 1 if state.get("stage") == "integration" else state.get("max_rounds", 5))
    results = []
    for group in groups:
        tasks = state.get("task_groups", {}).get(group, base_tasks)
        entries = [row for row in attempts if row["group"] == group]
        first = {row["task"] for row in entries if row["round"] == 1 and row["status"] == "solved"}
        solved = {row["task"] for row in entries if row["status"] == "solved"}
        incomplete = [row for row in entries if row["status"] not in ("solved", "not_solved")]
        failed = {task for task in tasks if task not in solved and any(
            row["task"] == task and row["round"] >= limit and row["status"] == "not_solved" for row in entries)}
        cumulative = []
        for round_num in range(1, 6):
            passed = {row["task"] for row in entries if row["round"] <= round_num and row["status"] == "solved"}
            assessed = passed | {row["task"] for row in entries if row["round"] == round_num
                                 and row["status"] in ("solved", "not_solved")}
            cumulative.append({"round": round_num, "solved_tasks": len(passed),
                               "assessed_tasks": len(assessed), "planned_tasks": len(tasks),
                               "pending_tasks": len(set(tasks) - assessed),
                               "within_protocol": round_num <= limit})
        results.append({"group": group, "planned_tasks": len(tasks),
                        "attempted_tasks": len({row["task"] for row in entries}),
                        "attempts": len(entries), "first_round_solved": len(first),
                        "solved_tasks": len(solved), "normal_failed_tasks": len(failed),
                        "incomplete_attempts": len(incomplete),
                        "normal_failed_attempts": sum(row["status"] == "not_solved" for row in entries),
                        "unfinished_tasks": len(set(tasks) - solved - failed),
                        "cumulative": cumulative})
    return results


def aggregate_experiment(experiment_state_path, bridge_dir, progress_dir=None, allocate_shared=False):
    state_path, bridge_dir = Path(experiment_state_path), Path(bridge_dir)
    state = read_json(state_path)
    catalog = experiment_catalog(state_path, state)
    rows, missing_fields = {}, defaultdict(int)
    def bucket(record):
        info = attribution(record, catalog)
        key = tuple(info[name] for name in DIMENSIONS)
        if key not in rows:
            rows[key] = dict(info, **counters())
        return rows[key]
    for record in records(bridge_dir / "token_usage.jsonl"):
        row = bucket(record)
        delta = record.get("delta") or {}
        for field, native in TOKEN_FIELDS.items():
            if native in delta:
                row[field] += delta[native]
            elif row["experiment"] == state["experiment"]:
                missing_fields[field] += 1
        row["token_events"] += 1
    for filename, field in (("model_requests.jsonl", "request_count"),
                            ("model_responses.jsonl", "response_count"),
                            ("model_errors.jsonl", "error_count")):
        for record in records(bridge_dir / filename):
            row = bucket(record)
            row[field] += 1
            if field != "request_count":
                row["request_seconds"] += record.get("elapsed_seconds", 0) or 0
    for record in records(bridge_dir / "codex_events.jsonl"):
        event = record.get("event") or {}
        turn = (event.get("params") or {}).get("turn") or {}
        if event.get("method") == "turn/completed" and turn.get("durationMs") is not None:
            row = bucket(record)
            row["codex_turn_count"] += 1
            row["codex_turn_seconds"] += turn["durationMs"] / 1000
    selected = [row for row in rows.values() if row["experiment"] == state["experiment"]]
    selected.sort(key=lambda row: tuple(str(row[name] or "") for name in DIMENSIONS))
    total, shared = counters(), counters()
    group_totals, scope_totals = defaultdict(counters), defaultdict(counters)
    for row in rows.values():
        add_counters(scope_totals[row["scope"]], row)
    for row in selected:
        add_counters(total, row)
        add_counters(group_totals[row["group"] or "unattributed"], row)
        if row["group"] == "shared":
            add_counters(shared, row)
    progress_dir = Path(progress_dir) if progress_dir else bridge_dir.parent / "progress"
    progress = [row for row in records(progress_dir / "progress.jsonl")
                if (row.get("session") or "").startswith(state["experiment"] + "-")]
    attempts = [] if state.get("dry_run") else state.get("attempts", [])
    attempt_rows = [attempt_metrics(row, state["experiment"], progress) for row in attempts]
    allocations = []
    if allocate_shared:
        for row in selected:
            if row["group"] != "shared":
                continue
            members = state.get("shared", {}).get(row["task"], {}).get("cost_shared_by", ["H", "M", "I"])
            for group in members:
                allocations.append({**{name: row[name] for name in DIMENSIONS}, "group": group,
                                    "allocation_only": True, "share": 1 / len(members),
                                    **{field: row[field] / len(members) for field in COUNTERS}})
    preflight_path = bridge_dir.parent.parent / "preflight" / "cli_tool_result.json"
    preflight = read_json(preflight_path)
    preflight_cli = None
    if preflight:
        native = (preflight.get("usage") or {}).get("total") or {}
        preflight_cli = {"source": str(preflight_path), "scope": "preflight_cli",
                         "elapsed_seconds": preflight.get("elapsed_seconds"),
                         "tokens": {field: native.get(key) for field, key in TOKEN_FIELDS.items()},
                         "included_in_experiment": False}
    return {"experiment": state["experiment"], "stage": state.get("stage"),
            "status": state.get("status"), "dry_run": state.get("dry_run", False),
            "model": state.get("model"), "reasoning_effort": state.get("reasoning_effort"),
            "stop_reason": state.get("stop_reason"), "state_source": str(state_path),
            "bridge_source": str(bridge_dir), "totals": total, "shared_totals": shared,
            "group_totals": dict(group_totals), "bridge_scope_totals": dict(scope_totals),
            "stages": selected, "attempts": attempt_rows, "outcomes": outcomes(state, attempts),
            "progress_checks": progress, "shared_allocations": allocations,
            "preflight_cli": preflight_cli, "missing_token_fields": dict(missing_fields),
            "dry_run_attempts_excluded": len(state.get("attempts", [])) if state.get("dry_run") else 0}


def write_csv(path, rows, fields):
    with Path(path).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def render_report(metrics):
    title = {"formal": "正式实验", "integration": "联调", "preflight": "预检"}.get(metrics["stage"], metrics["stage"])
    updated = datetime.now(timezone(timedelta(hours=8))).strftime("%Y-%m-%d %H:%M:%S")
    lines = [f"# Codex Hint {title}报告", "", f"更新时间：{updated}（北京时间）。",
             f"状态：{metrics['status']}；模型：{metrics['model']}；思考强度：{metrics['reasoning_effort']}。", ""]
    if metrics["dry_run"]:
        lines += ["本次是执行路径演练，所有占位成绩均排除，不计入实验结果。", ""]
    elif metrics["stage"] == "integration":
        lines += ["H 与 I 在各自指定题上验证流程，题目不同，不据此比较组间效果。", ""]
    lines += ["## 解题结果", "", "各组首轮与累计结果分开统计。未完成和未跑满轮次不等同正常失败。", "",
              "| 组别 | 已尝试题数 | 首轮通过 | 累计通过 | 跑满仍失败题数 | 未完成尝试 | 尚未结束题数 |",
              "|---|---:|---:|---:|---:|---:|---:|"]
    for row in metrics["outcomes"]:
        lines.append("| {group} | {attempted_tasks} | {first_round_solved} | {solved_tasks} | {normal_failed_tasks} | {incomplete_attempts} | {unfinished_tasks} |".format(**row))
    lines += ["", "B：无指导；H：原框架对齐版；M：教师会话连续；I：增加轮内指导。", "",
              "| 组别 | 第1轮累计 | 第2轮累计 | 第3轮累计 | 第4轮累计 | 第5轮累计 |",
              "|---|---:|---:|---:|---:|---:|"]
    for row in metrics["outcomes"]:
        values = [str(item["solved_tasks"]) if item["within_protocol"] else "不适用" for item in row["cumulative"]]
        lines.append("| " + row["group"] + " | " + " | ".join(values) + " |")
    lines += ["", "进行中或因额度停止时，累计通过是已观察到的数量；尚未执行的尝试不计为失败。每轮覆盖题数见 metrics.json。", "",
              "## 实际 Token 与模型请求耗时", "",
              "缓存输入包含在输入内，推理输出包含在输出内；总量采用模型返回的 totalTokens，不重复相加。", "",
              "| 归属 | 输入 | 缓存输入 | 输出 | 推理输出 | 总 Token | 请求耗时（秒） | 请求错误数 |",
              "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for group, row in sorted(metrics["group_totals"].items()):
        label = "共享初始教师与首轮压缩（仅计一次）" if group == "shared" else group
        lines.append(f"| {label} | {row['input_tokens']} | {row['cached_input_tokens']} | {row['output_tokens']} | {row['reasoning_output_tokens']} | {row['total_tokens']} | {row['request_seconds']:.2f} | {row['error_count']} |")
    total = metrics["totals"]
    lines += ["", f"当前实验实际总量：{total['total_tokens']} Token；模型请求耗时合计 {total['request_seconds']:.2f} 秒。",
              "共享初始产物只计一次；M 后续复盘归 M。分摊表若启用，仅供比较，不再加入实际总量。",
              "请求耗时是各请求耗时之和，不能当作系统墙钟；Codex 轮次耗时包含工具等待，不能当作纯推理时间。",
              "学生整次流程墙钟、SDK 解题墙钟、教师等待和扣除等待后的时间分列在 attempt_metrics.csv；缺失数据保留为空。", "",
              "## 阶段与数据边界", "",
              "各任务、组别、角色、阶段的明细见 token_usage_by_stage.csv；每次教师决定见原始 progress.jsonl。",
              "预检、联调和正式实验的 Token 分开列在 metrics.json.bridge_scope_totals；成绩仅使用当前实验状态。"]
    if metrics["preflight_cli"]:
        value = metrics["preflight_cli"]
        lines.append(f"独立 CLI 预检另记录 {value['tokens']['total_tokens']} Token、{value['elapsed_seconds']} 秒，未计入本实验总量。")
    if metrics["missing_token_fields"]:
        lines.append("部分 Token 字段未返回，明细只汇总已观测值，缺失事件数见 metrics.json.missing_token_fields。")
    lines.append("未提供可核对的货币账单，因此不换算美元费用。")
    if metrics["stop_reason"]:
        lines += ["", "停止原因：" + metrics["stop_reason"]]
    return "\n".join(lines) + "\n"


def write_reports(experiment_state_path, bridge_dir, progress_dir=None,
                  output_dir=None, allocate_shared=False):
    metrics = aggregate_experiment(experiment_state_path, bridge_dir, progress_dir, allocate_shared)
    output = Path(output_dir) if output_dir else Path(experiment_state_path).parent
    output.mkdir(parents=True, exist_ok=True)
    (output / "metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    write_csv(output / "token_usage_by_stage.csv", metrics["stages"], DIMENSIONS + COUNTERS)
    attempt_fields = ("task", "group", "round", "status", "reward", "f2p_passed", "f2p_total",
                      "p2p_passed", "p2p_total", "attempt_wall_seconds", "student_wall_seconds",
                      "teacher_wait_seconds", "teacher_wait_source", "student_active_seconds",
                      "teacher_checks", "delivered_hints", "stop_reason", "eval_path", "trajs_path")
    write_csv(output / "attempt_metrics.csv", metrics["attempts"], attempt_fields)
    if allocate_shared:
        write_csv(output / "shared_allocations.csv", metrics["shared_allocations"],
                  DIMENSIONS + ("allocation_only", "share") + COUNTERS)
    (output / "report.md").write_text(render_report(metrics), encoding="utf-8")
    return metrics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment_state", required=True)
    parser.add_argument("--bridge_dir", required=True)
    parser.add_argument("--progress_dir", default=None)
    parser.add_argument("--output_dir", default=None)
    parser.add_argument("--allocate_shared", action="store_true")
    args = parser.parse_args()
    write_reports(args.experiment_state, args.bridge_dir, args.progress_dir,
                  args.output_dir, args.allocate_shared)


if __name__ == "__main__":
    main()
