"""Measured fixture reports without model, Docker, or network calls."""

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "source"))
from report_codex_experiments import aggregate_experiment, write_reports  # noqa: E402


class ReportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.output = self.root / "runs" / "formal-one"
        self.output.mkdir(parents=True)
        self.bridge = self.root / "logs" / "bridge"
        self.bridge.mkdir(parents=True)
        self.progress = self.root / "logs" / "progress"
        self.progress.mkdir(parents=True)
        self.state_path = self.output / "experiment_state.json"
        self.state = {"experiment": "formal-one", "stage": "formal", "status": "stopped",
                      "model": "gpt-6.1-terra", "reasoning_effort": "low", "max_rounds": 5,
                      "groups": ["B", "H", "M", "I"], "tasks": ["task-a", "task-b"],
                      "shared": {"task-a": {"cost_shared_by": ["H", "M", "I"]}},
                      "attempts": [
                          {"task":"task-a", "group":"B", "round":1, "status":"not_solved"},
                          {"task":"task-a", "group":"B", "round":2, "status":"solved"},
                          {"task":"task-a", "group":"H", "round":1, "status":"solved"},
                          {"task":"task-a", "group":"M", "round":1, "status":"incomplete"},
                          {"task":"task-b", "group":"I", "round":1, "status":"not_solved", "elapsed_seconds":150},
                          {"task":"task-b", "group":"I", "round":2, "status":"incomplete"},
                      ]}
        self.save_state()
        integration = self.root / "runs" / "integration-one"
        integration.mkdir()
        (integration / "experiment_state.json").write_text(json.dumps({
            "experiment":"integration-one", "stage":"integration", "tasks":["task-a"], "attempts":[]}))

    def tearDown(self):
        self.tmp.cleanup()

    def save_state(self):
        self.state_path.write_text(json.dumps(self.state))

    def log(self, name, rows):
        (self.bridge / name).write_text("".join(json.dumps(row)+"\n" for row in rows))

    def usage(self, session, role, phase, inputs, outputs, cached=0, reasoning=0):
        return {"session":session, "role":role, "phase":phase,
                "delta":{"inputTokens":inputs,"cachedInputTokens":cached,"outputTokens":outputs,
                         "reasoningOutputTokens":reasoning,"totalTokens":inputs+outputs},
                "usage":{"total":{"totalTokens":999999}}}

    def fixtures(self):
        self.log("token_usage.jsonl", [
            self.usage("formal-one-task-a-shared","teacher","generate",100,20,60,7),
            self.usage("formal-one-task-a-shared-compress_r1","compressor","compress_r1",20,2,10,1),
            self.usage("formal-one-task-a-shared","teacher","review_r1",40,5,30,2),
            self.usage("formal-one-task-a-H-r1","student","solve",50,10,20,5),
            self.usage("formal-one-task-b-I-r1_progress_1_candidate","teacher","progress_1_candidate",30,5),
            self.usage("formal-one-task-b-I-r1_progress_1_screen","compressor","progress_1_screen",10,2),
            self.usage("formal-one-task-a-B-r2","student","solve",70,10),
            self.usage("preflight-sdk","student","solve",999,1),
            self.usage("integration-one-task-a-H-r1","student","solve",50,5),
        ])
        self.log("model_requests.jsonl", [{"session":"formal-one-task-a-H-r1","role":"student","phase":"solve"}])
        self.log("model_responses.jsonl", [{"session":"formal-one-task-a-H-r1","role":"student","phase":"solve",
                  "elapsed_seconds":2.5,"response":{"usage":{"total_tokens":9999999}}}])
        self.log("model_errors.jsonl", [{"session":"formal-one-task-a-shared","role":"teacher","phase":"review_r1",
                  "elapsed_seconds":1.5,"usage":{"totalTokens":100000}}])
        self.log("codex_events.jsonl", [{"session":"formal-one-task-a-H-r1","role":"student","phase":"solve",
                  "event":{"method":"turn/completed","params":{"turn":{"durationMs":6000}}}}])

    def test_delta_only_and_shared_memory_attribution(self):
        self.fixtures()
        result = aggregate_experiment(self.state_path, self.bridge)
        self.assertEqual(result["totals"]["total_tokens"],374)
        self.assertEqual(result["totals"]["input_tokens"] + result["totals"]["output_tokens"],374)
        self.assertEqual(result["shared_totals"]["total_tokens"],142)
        self.assertEqual(result["group_totals"]["M"]["total_tokens"],45)
        self.assertEqual(result["group_totals"]["I"]["total_tokens"],47)
        self.assertEqual(result["totals"]["request_seconds"],4)
        self.assertEqual(result["totals"]["codex_turn_seconds"],6)

    def test_scopes_and_optional_allocation_do_not_double_count(self):
        self.fixtures()
        result = aggregate_experiment(self.state_path,self.bridge,allocate_shared=True)
        self.assertEqual(result["bridge_scope_totals"]["preflight"]["total_tokens"],1000)
        self.assertEqual(result["bridge_scope_totals"]["integration"]["total_tokens"],55)
        self.assertEqual(result["bridge_scope_totals"]["formal"]["total_tokens"],374)
        self.assertAlmostEqual(sum(row["total_tokens"] for row in result["shared_allocations"]),142)
        self.assertEqual(result["totals"]["total_tokens"],374)

    def test_cumulative_results_and_incomplete_are_separate(self):
        result=aggregate_experiment(self.state_path,self.bridge)
        groups={row["group"]:row for row in result["outcomes"]}
        self.assertEqual(groups["B"]["first_round_solved"],0)
        self.assertEqual(groups["B"]["cumulative"][1]["solved_tasks"],1)
        self.assertEqual(groups["M"]["incomplete_attempts"],1)
        self.assertEqual(groups["M"]["normal_failed_attempts"],0)
        self.assertEqual(groups["I"]["normal_failed_attempts"],1)
        self.assertEqual(groups["I"]["normal_failed_tasks"],0)
        self.assertGreater(groups["I"]["cumulative"][4]["pending_tasks"],0)

    def test_student_wall_active_and_teacher_wait_sources(self):
        trajectory=self.output/"trajs.json"
        trajectory.write_text(json.dumps({"metadata":{"wall_seconds":100,"teacher_wait_seconds":25,"teacher_checks":1}}))
        self.state["attempts"][4]["trajs_path"]=str(trajectory)
        self.save_state()
        (self.progress/"progress.jsonl").write_text(json.dumps({"session":"formal-one-task-b-I-r1",
                 "duration_seconds":23,"hint":"Check both forms."})+"\n")
        result=aggregate_experiment(self.state_path,self.bridge)
        row=result["attempts"][4]
        self.assertEqual(row["attempt_wall_seconds"],150)
        self.assertEqual(row["student_wall_seconds"],100)
        self.assertEqual(row["teacher_wait_seconds"],25)
        self.assertEqual(row["student_active_seconds"],75)
        self.assertEqual(row["teacher_wait_source"],"student_metadata")
        self.assertEqual(row["delivered_hints"],1)
        self.assertIsNone(result["attempts"][5]["student_active_seconds"])

    def test_dry_run_placeholders_do_not_become_results(self):
        self.state["dry_run"]=True
        self.save_state()
        result=write_reports(self.state_path,self.bridge)
        self.assertEqual(result["attempts"],[])
        self.assertEqual(result["dry_run_attempts_excluded"],6)
        self.assertTrue(all(row["solved_tasks"]==0 for row in result["outcomes"]))
        self.assertIn("不计入实验结果",(self.output/"report.md").read_text())

    def test_chinese_outputs_and_independent_cli_preflight(self):
        self.fixtures()
        directory=self.root/"preflight";directory.mkdir()
        (directory/"cli_tool_result.json").write_text(json.dumps({"usage":{"total":{"totalTokens":17,
          "inputTokens":15,"cachedInputTokens":8,"outputTokens":2,"reasoningOutputTokens":1}},"elapsed_seconds":.5}))
        result=write_reports(self.state_path,self.bridge,allocate_shared=True)
        self.assertEqual(result["preflight_cli"]["tokens"]["total_tokens"],17)
        self.assertEqual(result["totals"]["total_tokens"],374)
        for name in ["metrics.json","token_usage_by_stage.csv","attempt_metrics.csv","shared_allocations.csv","report.md"]:
            self.assertTrue((self.output/name).is_file())
        text=(self.output/"report.md").read_text()
        self.assertIn("仅计一次",text)
        self.assertNotIn("$",text)


if __name__=="__main__":
    unittest.main()
