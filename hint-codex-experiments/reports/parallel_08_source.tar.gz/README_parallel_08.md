# 九题六路并行实验 08：统一展示 SDK 工具

2026-11-22，用户已接受统一工具配置并重新运行 Anko 之外的九题。本批准备完成后由主线程启动；本文件生成时尚未启动正式实验。

07 因 SDK 在会话中通过 ToolSearch 增加工具定义而停止，已有原生线程不能直接加入这些新工具。08 将全部可用 SDK 工具从首次请求起统一提供，学生与教师使用相同设置。这会改变模型最初看见的工具列表，因此九题作为新批次重新采样，07 的结果和用量单独保留。

## 唯一生产代码变化

`source_parallel_08_static/` 直接复制冻结的 `source_parallel_07/`，只在 `run_cc_sdk.py::create_agent_options` 的既有 `env` 中添加 `"ENABLE_TOOL_SEARCH": "false"`。其余生产文件逐字节相同。真实 SDK 验证首次阶段及同会话后续阶段都提供相同的 18 个工具，没有延迟工具。

本候选不包含 `source_parallel_08/` 中另行准备的恢复代码。08 不复用 07 的初始 Hint、学生代码或 M 教师原生会话。07 的五个教师会话及备份继续保留，不把新会话描述为旧会话续接。

## 实验设置

- 模型：所有角色继续使用 `gpt-6.1-terra`、推理强度 `low`；题目、模型 Prompt、GT、评分程序均沿用 07。
- 六套原 VM，各 8 vCPU、144 GiB，共 48 vCPU；每套学生及教师仍为 8 CPU / 128 GiB，评测容器内存 8 GiB。
- 固定队列：lane0 Claude Code → Termenv；lane1 Igel → Textual；lane2 Ink → Valibot；lane3 Kea；lane4 Obsidian Linter；lane5 SQLfmt。
- 每路依次解题，不同路并行；题内各组顺序保留原全局题序轮换。
- B、H、M、I 最多各 5 轮，通过后停止该组。H/M 共用一次实际首轮；共同失败后 H 使用新教师复盘，M 使用本批初始教师同一会话复盘。后续学生使用新环境和新会话。
- I 每完成 20 次主要工具调用检查一次，最多 3 次，每条指导最多 100 词。学生有效时限 7200 秒、教师 3600 秒、单次轮内教师检查 600 秒。
- 原 SDK、CLI、JIT 设置、工具执行位置、网络限制和教师只读代码权限保持不变。只有 SDK 工具首次展示方式改变；直接压缩等无工具调用阶段沿用原方式。
- 额度或技术异常继续保存并停止，不自动改变模型、购买或重置额度。

## 旧数据与本批统计边界

Anko 沿用 03/04 的 7 次已完成评测，不重跑，仍作为 v1 过渡结果。Anko 没有采用本批统一工具展示条件，不用于宣称本批四组在十题上具有完全相同运行条件。

07 的 Ink I1 学生此前已经正常结束，后来仅补评测：F2P 为 0/25，P2P 为 49/49，未解出。该结果在 `runs/codex_parallel_07_eval_recovery/attempts.json` 单列，不导入 08 九题的成绩。07 其他五次学生技术中断也不计正常失败，不用 08 新结果覆盖。

正式输出为 `runs/codex_parallel_08/`。实际 token 继续追加到原账本，按批次/角色/阶段归集；08 新增用量与原历史总量分别记录，不把先前失败批次成本隐藏或重复相加。

## 已完成验证与启动材料

原 106 项离线测试全部通过；六路九题完整编排演练通过，没有真实模型调用。演练的占位成绩不计入实验。

真实 SDK 的禁网模拟验证使用候选 `create_agent_options` 内部配置，外部环境没有设置 `ENABLE_TOOL_SEARCH`；首次及同会话后续阶段执行 Read、Edit、Bash，工具列表保持 18 项一致。此测试使用模拟模型响应，用量不计入实验。

- 配置：`reports/parallel_08_config.json`
- 源码差异：`reports/parallel_08_source_changes.diff`
- 源码与操作归档：`reports/parallel_08_snapshot.json`
- 离线测试：`preflight/offline_tests_parallel_08_static.json`
- 编排演练：`preflight/parallel_08_dryrun_result.json`
- 真实 SDK 工具验证：`preflight/parallel_08_sdk_candidate_tools/result.json`
- 启动脚本：`preflight/launch_parallel_08.py`

旧 07 服务已经关闭，完整关闭前快照在 `preflight/parallel_08_service_shutdown/`。启动脚本先将这些记录复制到新启动记录目录，再创建新服务；不会要求旧服务仍然在线。主线程在最终检查账户额度及环境后执行启动脚本。
